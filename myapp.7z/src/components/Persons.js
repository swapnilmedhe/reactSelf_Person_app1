import React from 'react';
import { Card, Button, CardTitle, CardText } from 'reactstrap';
import "./Person.css";


function Persons(props) {
  //console.log(props);
  const data= props.p.map((per ,index) =>
  
  <div className="person" onClick={() =>props.clickme(index)} key={index}> {per}</div>);
   
  return (
   <div className="Conatiner border: 1px solid red">
       {data}
   </div>
        
  )
}

export default Persons
