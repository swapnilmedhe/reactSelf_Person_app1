import React, { Component } from 'react';
import './App.css';
import Persons from "./components/Persons";
import { Spinner } from 'reactstrap';

//import {Button} from "reactstrap";
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';



class App extends Component {
  
  constructor(){
    super();

    this.state={
      person:["person1" ,"person2","person3","person4","person5"],
      model: false,
      newperson:"",
    }
    this.toggle=this.toggle.bind(this);
  }

  deletehandler(index)
  {
    console.log(index);
    const person2=[...this.state.person]
    person2.splice(index,1);
    this.setState({
      person:person2
    });
  }

  openmodel =(per) =>
  {
    this.setState({
     modal: !per.modal,
    
    })
    console.log("modal open ");
  }

  addPersonhandler1 =()=>
  {
    let newp=this.state.newperson;
    const person2=[...this.state.person,newp]
    console.log(person2)
    this.setState({
      person:person2,
      modal: false,
    
    })
  }
  onChangehnadler =(e) =>
  {
    this.setState({newperson:e.target.value});
    console.log(this.state.newperson);
  }

  toggle =() => {
    this.setState(prevState => ({
      modal: !prevState.modal
    }));
  }

  render() {
   
    return (
    
      <div className="App">
        <h2>Demo ptactice </h2>
         <Persons p={this.state.person} clickme={(index)=>this.deletehandler(index)}/>

        
         <button onClick={this.openmodel} className="btn btn-info">Add person</button>
         <Modal isOpen={this.state.modal} toggle={this.toggle} >
          <ModalHeader toggle={this.toggle}>Add Person</ModalHeader>
           <ModalBody>
           <input type ="text"placeholder="Enter name..." onChange={this.onChangehnadler}  width="100%" name="pname"/>
          </ModalBody> 
          <ModalFooter>
            <Button color="primary" onClick={this.addPersonhandler1}>Add Person</Button>{' '} 
            <Button color="danger" onClick={this.toggle}>Cancel</Button>
          </ModalFooter>
        </Modal>
       
          <Spinner size="sm" color="primary" />
        
      
       
      </div>
    );
  }
}

export default App;
